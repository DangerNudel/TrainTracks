#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
# FONT DOWNLOADER — Run on an internet-connected machine
# Then copy the fonts/ directory to the lab host:
#   scp -r fonts/ labhost:/opt/scrn-lab/static/fonts/
# ═══════════════════════════════════════════════════════════
set -e

FONT_DIR="$(dirname "$0")/static/fonts"
mkdir -p "$FONT_DIR"

BASE="https://github.com/google/fonts/raw/main"

echo "[*] Downloading fonts from Google Fonts GitHub repo..."

# Share Tech Mono
curl -sL "${BASE}/ofl/sharetechmono/ShareTechMono-Regular.ttf" -o "${FONT_DIR}/ShareTechMono-Regular.ttf"
echo "  ✓ Share Tech Mono"

# Orbitron
for w in Regular Medium Bold ExtraBold; do
  curl -sL "${BASE}/ofl/orbitron/Orbitron-${w}.ttf" -o "${FONT_DIR}/Orbitron-${w}.ttf"
done
echo "  ✓ Orbitron (4 weights)"

# Rajdhani
for w in Regular SemiBold Bold; do
  curl -sL "${BASE}/ofl/rajdhani/Rajdhani-${w}.ttf" -o "${FONT_DIR}/Rajdhani-${w}.ttf"
done
echo "  ✓ Rajdhani (3 weights)"

# Chakra Petch
for w in Light Regular SemiBold Bold; do
  curl -sL "${BASE}/ofl/chakrapetch/ChakraPetch-${w}.ttf" -o "${FONT_DIR}/ChakraPetch-${w}.ttf"
done
echo "  ✓ Chakra Petch (4 weights)"

# Courier Prime
curl -sL "${BASE}/ofl/courierprime/CourierPrime-Regular.ttf" -o "${FONT_DIR}/CourierPrime-Regular.ttf"
echo "  ✓ Courier Prime"

echo ""
echo "[✓] All fonts downloaded to ${FONT_DIR}/"
echo "    Copy to lab host: scp -r static/fonts/ labhost:/opt/scrn-lab/static/fonts/"
ls -la "${FONT_DIR}"/*.ttf
