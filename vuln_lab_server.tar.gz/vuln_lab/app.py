#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════
  SC RAIL / HOOVER DAM LAB SERVER
  INTENTIONALLY VULNERABLE — AUTHORIZED TRAINING USE ONLY
═══════════════════════════════════════════════════════════════
  Vulnerabilities present (for classroom exploitation):
    1. SQL Injection on login (authentication bypass)
    2. OS Command Injection on diagnostics page (post-auth RCE)
    3. Weak / default credentials
    4. Verbose error messages (information disclosure)
    5. No CSRF protection
    6. Session fixation possible
    7. Directory traversal on file viewer

  Designed for exploitation with msfconsole:
    - auxiliary/scanner/http/http_login  (brute force creds)
    - exploit/unix/webapp/generic_exec   (command injection)
    - Or manual SQLi + reverse shell via injection point

  DO NOT deploy outside an isolated lab network.
═══════════════════════════════════════════════════════════════
"""

import os
import sys
import sqlite3
import subprocess
import hashlib
from datetime import datetime
from flask import (
    Flask, request, render_template, redirect,
    url_for, session, send_from_directory, make_response
)

app = Flask(__name__)
app.secret_key = 'SuperSecretKey123!'  # Vuln: Hardcoded weak secret

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'users.db')
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')

# ═══════════════════════════════════════════════════════════
# DATABASE SETUP
# ═══════════════════════════════════════════════════════════

def init_db():
    """Create users table with default credentials."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'operator',
        full_name TEXT,
        last_login TEXT
    )''')
    # Default credentials (Vuln: weak/guessable passwords)
    defaults = [
        ('admin', 'admin123', 'admin', 'System Administrator'),
        ('operator', 'operator', 'operator', 'Rail Operator'),
        ('engineer', 'hoover2024', 'engineer', 'Dam Engineer'),
        ('guest', 'guest', 'guest', 'Guest Account'),
    ]
    c.execute("SELECT COUNT(*) FROM users")
    if c.fetchone()[0] == 0:
        for u, p, r, n in defaults:
            c.execute(
                "INSERT INTO users (username, password, role, full_name) VALUES (?, ?, ?, ?)",
                (u, p, r, n)
            )
    conn.commit()
    conn.close()


# ═══════════════════════════════════════════════════════════
# ROUTES
# ═══════════════════════════════════════════════════════════

@app.route('/')
def index():
    if 'user' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')

        # ╔══════════════════════════════════════════════════╗
        # ║  VULNERABILITY: SQL INJECTION                    ║
        # ║  String concatenation in SQL query allows        ║
        # ║  authentication bypass via crafted input.        ║
        # ║                                                  ║
        # ║  Exploit examples:                               ║
        # ║    username: ' OR 1=1--                          ║
        # ║    username: admin'--                            ║
        # ║    username: ' UNION SELECT 1,'admin','admin',   ║
        # ║              'admin','Admin','2024'--            ║
        # ╚══════════════════════════════════════════════════╝
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            query = (
                "SELECT * FROM users WHERE username='"
                + username
                + "' AND password='"
                + password
                + "'"
            )

            # Vuln: Verbose error — echoes the query on failure
            app.logger.info(f"Executing query: {query}")

            c.execute(query)
            user = c.fetchone()
            conn.close()

            if user:
                session['user'] = user[1]       # username
                session['role'] = user[3]       # role
                session['full_name'] = user[4]  # full_name
                session['login_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                return redirect(url_for('dashboard'))
            else:
                # Vuln: Information disclosure — different message for
                # "user exists but wrong password" vs "user not found"
                conn = sqlite3.connect(DB_PATH)
                c = conn.cursor()
                c.execute("SELECT * FROM users WHERE username=?", (username,))
                if c.fetchone():
                    error = f"Invalid password for user '{username}'"
                else:
                    error = f"User '{username}' not found in database"
                conn.close()

        except Exception as e:
            # Vuln: Full stack trace / query exposed on error
            error = f"Database error: {str(e)} — Query: {query}"

    return render_template('login.html', error=error)


@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html',
        user=session.get('user'),
        role=session.get('role'),
        name=session.get('full_name'),
        login_time=session.get('login_time'),
    )


@app.route('/rail-control')
def rail_control():
    if 'user' not in session:
        return redirect(url_for('login'))
    return send_from_directory(STATIC_DIR, 'sc_rail_control.html')


@app.route('/hoover-dam')
def hoover_dam():
    if 'user' not in session:
        return redirect(url_for('login'))
    return send_from_directory(STATIC_DIR, 'hoover_dam_wireframe.html')


@app.route('/diagnostics', methods=['GET', 'POST'])
def diagnostics():
    """
    ╔══════════════════════════════════════════════════════════╗
    ║  VULNERABILITY: OS COMMAND INJECTION                     ║
    ║  User input is passed directly to subprocess.Popen()     ║
    ║  via shell=True with no sanitization.                    ║
    ║                                                          ║
    ║  Exploit via msfconsole:                                 ║
    ║    use exploit/multi/http/generic_cmd_injection           ║
    ║    (or manual: 127.0.0.1; id; cat /etc/passwd)           ║
    ║                                                          ║
    ║  POST /diagnostics                                       ║
    ║    target=<ip>;  <malicious command>                      ║
    ║    tool=ping|traceroute|nslookup|netstat                  ║
    ╚══════════════════════════════════════════════════════════╝
    """
    if 'user' not in session:
        return redirect(url_for('login'))

    output = None
    cmd_run = None
    target = ''
    tool = 'ping'

    if request.method == 'POST':
        target = request.form.get('target', '')
        tool = request.form.get('tool', 'ping')

        # Build command — NO SANITIZATION (intentional vuln)
        if tool == 'ping':
            cmd = f"ping -c 3 {target}"
        elif tool == 'traceroute':
            cmd = f"traceroute -m 10 {target}"
        elif tool == 'nslookup':
            cmd = f"nslookup {target}"
        elif tool == 'netstat':
            cmd = f"netstat -an | head -30"
        elif tool == 'arp':
            cmd = f"arp -a {target}"
        else:
            cmd = f"echo 'Unknown tool: {tool}'"

        cmd_run = cmd

        try:
            # Vuln: shell=True + unsanitized input = RCE
            proc = subprocess.Popen(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=15
            )
            stdout, _ = proc.communicate(timeout=15)
            output = stdout.decode('utf-8', errors='replace')
        except subprocess.TimeoutExpired:
            output = "Command timed out (15s limit)"
        except Exception as e:
            output = f"Error: {str(e)}"

    return render_template('diagnostics.html',
        user=session.get('user'),
        role=session.get('role'),
        output=output,
        cmd_run=cmd_run,
        target=target,
        tool=tool,
    )


@app.route('/files')
def file_viewer():
    """
    ╔══════════════════════════════════════════════════════════╗
    ║  VULNERABILITY: DIRECTORY TRAVERSAL                      ║
    ║  The 'path' parameter is not sanitized, allowing         ║
    ║  reading arbitrary files on the system.                   ║
    ║                                                          ║
    ║  Exploit: /files?path=../../../etc/passwd                 ║
    ╚══════════════════════════════════════════════════════════╝
    """
    if 'user' not in session:
        return redirect(url_for('login'))

    filepath = request.args.get('path', '')
    content = None
    error = None

    if filepath:
        try:
            # Vuln: No path sanitization — directory traversal
            base = os.path.join(STATIC_DIR, filepath)
            with open(base, 'r') as f:
                content = f.read()
        except Exception as e:
            error = f"Cannot read file: {str(e)}"

    files = []
    try:
        files = os.listdir(STATIC_DIR)
    except:
        pass

    return render_template('files.html',
        user=session.get('user'),
        files=files,
        filepath=filepath,
        content=content,
        error=error,
    )


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


# Vuln: Server version header exposed
@app.after_request
def add_headers(response):
    response.headers['X-Powered-By'] = 'Flask/2.3.0 Python/3.11'
    response.headers['Server'] = 'SCRN-LabServer/2.4.1'
    # Vuln: No security headers
    return response


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

if __name__ == '__main__':
    init_db()
    print("""
    ╔══════════════════════════════════════════════════════════╗
    ║   SC RAIL / HOOVER DAM — VULNERABLE LAB SERVER           ║
    ║   ⚠  INTENTIONALLY VULNERABLE — DO NOT EXPOSE TO WAN    ║
    ╠══════════════════════════════════════════════════════════╣
    ║   Listening on: http://0.0.0.0:8080                      ║
    ║                                                          ║
    ║   Default credentials:                                   ║
    ║     admin    / admin123                                   ║
    ║     operator / operator                                   ║
    ║     engineer / hoover2024                                 ║
    ║     guest    / guest                                      ║
    ║                                                          ║
    ║   Vulnerabilities:                                       ║
    ║     • SQL Injection    → /login                          ║
    ║     • Command Injection → /diagnostics                   ║
    ║     • Directory Traversal → /files                       ║
    ║     • Weak Credentials                                   ║
    ║     • Information Disclosure                             ║
    ║     • No CSRF / No Security Headers                      ║
    ╚══════════════════════════════════════════════════════════╝
    """)
    app.run(host='0.0.0.0', port=8080, debug=True)  # Vuln: debug=True in prod
