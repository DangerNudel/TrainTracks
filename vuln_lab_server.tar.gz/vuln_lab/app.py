#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════
  SC RAIL / HOOVER DAM LAB SERVER
  ZERO DEPENDENCIES — Python 3 stdlib only (wsgiref)
  INTENTIONALLY VULNERABLE — AUTHORIZED TRAINING USE ONLY
═══════════════════════════════════════════════════════════════
"""

import os, sys, re, sqlite3, subprocess, uuid, urllib.parse, traceback, mimetypes
from datetime import datetime
from wsgiref.simple_server import make_server, WSGIRequestHandler
from http.cookies import SimpleCookie

DIR  = os.path.dirname(os.path.abspath(__file__))
DB   = os.path.join(DIR, 'users.db')
SDIR = os.path.join(DIR, 'static')
TDIR = os.path.join(DIR, 'templates')

sessions = {}

# ═══════════════════════════════════════════════════════════
# DATABASE
# ═══════════════════════════════════════════════════════════

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT, password TEXT, role TEXT DEFAULT 'operator',
        full_name TEXT, last_login TEXT)''')
    c.execute("SELECT COUNT(*) FROM users")
    if c.fetchone()[0] == 0:
        for row in [('admin','admin123','admin','System Administrator'),
                     ('operator','operator','operator','Rail Operator'),
                     ('engineer','hoover2024','engineer','Dam Engineer'),
                     ('guest','guest','guest','Guest Account')]:
            c.execute("INSERT INTO users (username,password,role,full_name) VALUES (?,?,?,?)", row)
    conn.commit(); conn.close()

# ═══════════════════════════════════════════════════════════
# TEMPLATE ENGINE
# ═══════════════════════════════════════════════════════════

def render(name, **ctx):
    with open(os.path.join(TDIR, name)) as f:
        html = f.read()
    # {% if var %}...{% else %}...{% endif %}
    for _ in range(10):
        prev = html
        def _if(m):
            v = ctx.get(m.group(1).strip())
            return m.group(2) if v else (m.group(3) or '')
        html = re.sub(r'\{%\s*if\s+(\w+)\s*%\}(.*?)(?:\{%\s*else\s*%\}(.*?))?\{%\s*endif\s*%\}',
                       _if, html, flags=re.DOTALL)
        if html == prev: break
    # {{ var }}
    def _var(m):
        e = m.group(1).strip()
        if ' or ' in e:
            k, d = e.split(' or ', 1)
            v = ctx.get(k.strip())
            return str(v) if v else d.strip().strip("'\"")
        v = ctx.get(e, '')
        return str(v) if v is not None else ''
    html = re.sub(r'\{\{\s*(.+?)\s*\}\}', _var, html)
    return html

# ═══════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════

def esc(s):
    return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')

def get_session(environ):
    raw = environ.get('HTTP_COOKIE', '')
    if not raw: return None, None
    c = SimpleCookie()
    try: c.load(raw)
    except: return None, None
    s = c.get('session_id')
    if s and s.value in sessions:
        return sessions[s.value], s.value
    return None, None

def parse_post(environ):
    try:
        length = int(environ.get('CONTENT_LENGTH', 0))
    except:
        length = 0
    body = environ['wsgi.input'].read(length).decode('utf-8') if length > 0 else ''
    return urllib.parse.parse_qs(body)

def tool_options(sel='ping'):
    opts = [('ping','Ping (ICMP Echo)'),('traceroute','Traceroute'),
            ('nslookup','DNS Lookup'),('arp','ARP Table'),('netstat','Netstat')]
    return ''.join(f'<option value="{v}"{" selected" if v==sel else ""}>{l}</option>' for v,l in opts)

def file_listing():
    try: files = sorted(os.listdir(SDIR))
    except: return '<div style="padding:8px 18px;color:#005a66;">No files</div>'
    if not files: return '<div style="padding:8px 18px;color:#005a66;">No files</div>'
    return ''.join(f'<div class="file-item"><span style="color:#005a66;">📄</span> '
                   f'<a href="/files?path={urllib.parse.quote(f)}">{esc(f)}</a></div>' for f in files)

# ═══════════════════════════════════════════════════════════
# WSGI APPLICATION
# ═══════════════════════════════════════════════════════════

def application(environ, start_response):
    method = environ['REQUEST_METHOD']
    path = environ.get('PATH_INFO', '/').rstrip('/') or '/'
    query = urllib.parse.parse_qs(environ.get('QUERY_STRING', ''))

    try:
        # ── Static files ──
        if path.startswith('/fonts/') or path.startswith('/static/'):
            return serve_static(environ, start_response, path)

        # ── GET routes ──
        if method == 'GET':
            if path == '/':
                return redirect(start_response, '/login')

            elif path == '/login':
                return html_response(start_response, 200,
                    render('login.html', error=''))

            elif path == '/dashboard':
                s, _ = get_session(environ)
                if not s: return redirect(start_response, '/login')
                return html_response(start_response, 200,
                    render('dashboard.html', **s))

            elif path == '/rail-control':
                s, _ = get_session(environ)
                if not s: return redirect(start_response, '/login')
                return serve_file(start_response, os.path.join(SDIR, 'sc_rail_control.html'))

            elif path == '/hoover-dam':
                s, _ = get_session(environ)
                if not s: return redirect(start_response, '/login')
                return serve_file(start_response, os.path.join(SDIR, 'hoover_dam_wireframe.html'))

            elif path == '/diagnostics':
                s, _ = get_session(environ)
                if not s: return redirect(start_response, '/login')
                return html_response(start_response, 200,
                    render('diagnostics.html', tool_options=tool_options('ping'),
                           output='', cmd_run='', target='', **s))

            elif path == '/files':
                s, _ = get_session(environ)
                if not s: return redirect(start_response, '/login')
                return handle_files(start_response, query, s)

            elif path == '/logout':
                _, sid = get_session(environ)
                if sid and sid in sessions: del sessions[sid]
                return redirect(start_response, '/login',
                    cookie='session_id=x; Path=/; Max-Age=0')

            else:
                # Try serving from static/
                fp = os.path.join(SDIR, path.lstrip('/'))
                if os.path.isfile(fp):
                    return serve_file(start_response, fp)
                return html_response(start_response, 404, '<h1>404 Not Found</h1>')

        # ── POST routes ──
        elif method == 'POST':
            post = parse_post(environ)

            if path == '/login':
                return handle_login(environ, start_response, post)

            elif path == '/diagnostics':
                s, _ = get_session(environ)
                if not s: return redirect(start_response, '/login')
                return handle_diagnostics(start_response, post, s)

            return html_response(start_response, 404, '<h1>404 Not Found</h1>')

        return html_response(start_response, 405, '<h1>405 Method Not Allowed</h1>')

    except Exception:
        traceback.print_exc()
        return html_response(start_response, 500,
            f'<h1>500 Internal Server Error</h1><pre>{esc(traceback.format_exc())}</pre>')

# ═══════════════════════════════════════════════════════════
# RESPONSE HELPERS
# ═══════════════════════════════════════════════════════════

def html_response(start_response, code, body, cookie=None):
    data = body.encode('utf-8')
    status = f'{code} OK' if code == 200 else f'{code} Error'
    headers = [
        ('Content-Type', 'text/html; charset=utf-8'),
        ('Content-Length', str(len(data))),
        ('X-Powered-By', 'Python/3.11 stdlib'),
        ('Server', 'SCRN-LabServer/2.4.1'),
    ]
    if cookie:
        headers.append(('Set-Cookie', cookie))
    start_response(status, headers)
    return [data]

def redirect(start_response, url, cookie=None):
    headers = [
        ('Location', url),
        ('Content-Type', 'text/html; charset=utf-8'),
        ('Content-Length', '0'),
    ]
    if cookie:
        headers.append(('Set-Cookie', cookie))
    start_response('302 Found', headers)
    return [b'']

def serve_file(start_response, filepath):
    try:
        with open(filepath, 'rb') as f:
            data = f.read()
    except FileNotFoundError:
        return html_response(start_response, 404, '<h1>404 Not Found</h1>')
    ct, _ = mimetypes.guess_type(filepath)
    if ct is None:
        ct = 'application/octet-stream'
    # Force correct types for fonts
    if filepath.endswith('.ttf'): ct = 'font/ttf'
    elif filepath.endswith('.woff2'): ct = 'font/woff2'
    elif filepath.endswith('.woff'): ct = 'font/woff'
    headers = [
        ('Content-Type', ct),
        ('Content-Length', str(len(data))),
    ]
    start_response('200 OK', headers)
    return [data]

def serve_static(environ, start_response, path):
    # /fonts/X → static/fonts/X
    # /static/X → static/X
    if path.startswith('/fonts/'):
        fp = os.path.join(SDIR, 'fonts', path[7:])
    else:
        fp = os.path.join(SDIR, path[8:])
    if os.path.isfile(fp):
        return serve_file(start_response, fp)
    return html_response(start_response, 404, '<h1>404</h1>')

# ═══════════════════════════════════════════════════════════
# LOGIN — SQL INJECTION
# ═══════════════════════════════════════════════════════════

def handle_login(environ, start_response, post):
    username = post.get('username', [''])[0]
    password = post.get('password', [''])[0]
    error = ''; query = ''

    try:
        conn = sqlite3.connect(DB)
        c = conn.cursor()

        # ╔══════════════════════════════════════════════════════╗
        # ║  VULNERABILITY: SQL INJECTION                        ║
        # ║  String concatenation — no parameterized query.      ║
        # ║  Exploit:  username = ' OR 1=1--                     ║
        # ╚══════════════════════════════════════════════════════╝
        query = ("SELECT * FROM users WHERE username='"
                 + username + "' AND password='" + password + "'")
        print(f"  [SQL] {query}")
        c.execute(query)
        user = c.fetchone()
        conn.close()

        if user:
            sid = uuid.uuid4().hex
            sessions[sid] = {
                'user': str(user[1]),
                'role': str(user[3] or 'operator'),
                'name': str(user[4] or user[1]),
                'login_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            }
            return redirect(start_response, '/dashboard',
                cookie=f'session_id={sid}; Path=/')

        # Vuln: user enumeration via different error messages
        conn = sqlite3.connect(DB)
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=?", (username,))
        if c.fetchone():
            error = f"Invalid password for user '{esc(username)}'"
        else:
            error = f"User '{esc(username)}' not found in database"
        conn.close()

    except Exception as e:
        # Vuln: full error + query exposed
        error = f"Database error: {esc(str(e))} — Query: {esc(query)}"

    return html_response(start_response, 200,
        render('login.html', error=error))

# ═══════════════════════════════════════════════════════════
# DIAGNOSTICS — COMMAND INJECTION
# ═══════════════════════════════════════════════════════════

def handle_diagnostics(start_response, post, session):
    target = post.get('target', [''])[0]
    tool   = post.get('tool', ['ping'])[0]

    # ╔══════════════════════════════════════════════════════════╗
    # ║  VULNERABILITY: OS COMMAND INJECTION                     ║
    # ║  Unsanitized input + shell=True = RCE                    ║
    # ║  Exploit: target = 127.0.0.1; id                         ║
    # ╚══════════════════════════════════════════════════════════╝
    cmds = {
        'ping':       f"ping -c 3 {target}",
        'traceroute': f"traceroute -m 10 {target}",
        'nslookup':   f"nslookup {target}",
        'netstat':    "netstat -an | head -30",
        'arp':        f"arp -a {target}",
    }
    cmd = cmds.get(tool, f"echo 'Unknown: {tool}'")
    output = ''

    try:
        proc = subprocess.Popen(cmd, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stdout, _ = proc.communicate(timeout=15)
        output = esc(stdout.decode('utf-8', errors='replace'))
    except subprocess.TimeoutExpired:
        proc.kill()
        output = "Command timed out (15s limit)"
    except Exception as e:
        output = f"Error: {esc(str(e))}"

    return html_response(start_response, 200,
        render('diagnostics.html',
            tool_options=tool_options(tool),
            output=output,
            cmd_run=esc(cmd),
            target=esc(target),
            **session))

# ═══════════════════════════════════════════════════════════
# FILES — DIRECTORY TRAVERSAL
# ═══════════════════════════════════════════════════════════

def handle_files(start_response, query, session):
    filepath = query.get('path', [''])[0]
    content = ''; error = ''

    if filepath:
        try:
            # ╔════════════════════════════════════════════════╗
            # ║  VULNERABILITY: DIRECTORY TRAVERSAL             ║
            # ║  No path sanitization before open()             ║
            # ║  Exploit: ?path=../../../etc/passwd              ║
            # ╚════════════════════════════════════════════════╝
            with open(os.path.join(SDIR, filepath), 'r', errors='replace') as f:
                content = esc(f.read())
        except Exception as e:
            error = f"Cannot read: {esc(str(e))}"

    return html_response(start_response, 200,
        render('files.html',
            filepath=esc(filepath),
            content=content,
            error=error,
            files_list=file_listing(),
            **session))

# ═══════════════════════════════════════════════════════════
# QUIET LOGGER
# ═══════════════════════════════════════════════════════════

class QuietHandler(WSGIRequestHandler):
    def log_request(self, code='-', size='-'):
        sys.stderr.write(f"  [{datetime.now():%H:%M:%S}] {self.command} {self.path} → {code}\n")

# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

if __name__ == '__main__':
    init_db()
    host, port = '0.0.0.0', 8080
    print(f"""
    ╔══════════════════════════════════════════════════════════╗
    ║   SC RAIL / HOOVER DAM — VULNERABLE LAB SERVER           ║
    ║   ⚠  INTENTIONALLY VULNERABLE — DO NOT EXPOSE TO WAN    ║
    ╠══════════════════════════════════════════════════════════╣
    ║   http://0.0.0.0:{port}                                  ║
    ║   Python wsgiref — ZERO external dependencies            ║
    ║                                                          ║
    ║   Creds:  admin/admin123   operator/operator             ║
    ║           engineer/hoover2024   guest/guest              ║
    ║                                                          ║
    ║   Vulns:  SQLi → /login    RCE → /diagnostics            ║
    ║           LFI  → /files    Weak creds · Info disclosure   ║
    ╚══════════════════════════════════════════════════════════╝
    """)
    server = make_server(host, port, application, handler_class=QuietHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Stopped.")
        server.server_close()
