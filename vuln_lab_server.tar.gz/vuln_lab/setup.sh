#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
#  SCRN VULNERABLE LAB SERVER — DEBIAN 12 SETUP
#  Authorized training use only — isolated lab networks
# ═══════════════════════════════════════════════════════════
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'
AMBER='\033[0;33m'; BOLD='\033[1m'; NC='\033[0m'

banner() {
cat << 'EOF'

  ╔══════════════════════════════════════════════════════════╗
  ║    ___  ___ ___  _  _   _      _     ___                ║
  ║   / __|/ __| _ \| \| | | |    /_\   | _ )               ║
  ║   \__ \ (__|   /| .` | | |__ / _ \  | _ \               ║
  ║   |___/\___|_|_\|_|\_| |____/_/ \_\ |___/               ║
  ║                                                          ║
  ║   Vulnerable Lab Server — Debian 12 Setup                ║
  ║   ⚠  INTENTIONALLY VULNERABLE — TRAINING USE ONLY       ║
  ╚══════════════════════════════════════════════════════════╝

EOF
}

log()  { echo -e "${CYAN}[*]${NC} $1"; }
ok()   { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${AMBER}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; }

banner

# ── Check root ──
if [ "$EUID" -ne 0 ]; then
  err "Run as root:  sudo ./setup.sh"
  exit 1
fi

# ── Check Debian 12 ──
if [ -f /etc/os-release ]; then
  . /etc/os-release
  log "Detected: $PRETTY_NAME"
else
  warn "Cannot detect OS — continuing anyway"
fi

echo ""
warn "════════════════════════════════════════════════════"
warn "  THIS INSTALLS AN INTENTIONALLY VULNERABLE SERVER"
warn "  DO NOT RUN ON PRODUCTION OR INTERNET-FACING HOSTS"
warn "════════════════════════════════════════════════════"
echo ""
read -p "Continue with installation? (yes/no): " CONFIRM
if [ "$CONFIRM" != "yes" ]; then
  echo "Aborted."
  exit 0
fi

# ═══════════════════════════════════════════════════════════
# 1. INSTALL SYSTEM DEPENDENCIES
# ═══════════════════════════════════════════════════════════
log "Installing system packages..."

apt-get update -qq

apt-get install -y -qq \
  python3 \
  python3-pip \
  python3-venv \
  net-tools \
  traceroute \
  dnsutils \
  iputils-ping \
  sqlite3 \
  curl \
  2>/dev/null

ok "System packages installed"

# ═══════════════════════════════════════════════════════════
# 2. SETUP APPLICATION DIRECTORY
# ═══════════════════════════════════════════════════════════
APP_DIR="/opt/scrn-lab"
log "Setting up application in ${APP_DIR}..."

mkdir -p "${APP_DIR}/static"
mkdir -p "${APP_DIR}/templates"

# Copy application files
cp "${SCRIPT_DIR}/app.py"                    "${APP_DIR}/app.py"
cp "${SCRIPT_DIR}/templates/login.html"      "${APP_DIR}/templates/login.html"
cp "${SCRIPT_DIR}/templates/dashboard.html"  "${APP_DIR}/templates/dashboard.html"
cp "${SCRIPT_DIR}/templates/diagnostics.html" "${APP_DIR}/templates/diagnostics.html"
cp "${SCRIPT_DIR}/templates/files.html"      "${APP_DIR}/templates/files.html"

# Copy the HTML applications to static/
if [ -f "${SCRIPT_DIR}/static/sc_rail_control.html" ]; then
  cp "${SCRIPT_DIR}/static/sc_rail_control.html" "${APP_DIR}/static/"
  ok "SC Rail Control copied"
else
  warn "sc_rail_control.html not found in static/ — copy manually"
fi

if [ -f "${SCRIPT_DIR}/static/hoover_dam_wireframe.html" ]; then
  cp "${SCRIPT_DIR}/static/hoover_dam_wireframe.html" "${APP_DIR}/static/"
  ok "Hoover Dam schematic copied"
else
  warn "hoover_dam_wireframe.html not found in static/ — copy manually"
fi

ok "Application files deployed to ${APP_DIR}"

# ═══════════════════════════════════════════════════════════
# 3. PYTHON VIRTUAL ENVIRONMENT + FLASK
# ═══════════════════════════════════════════════════════════
log "Creating Python virtual environment..."

python3 -m venv "${APP_DIR}/venv"
source "${APP_DIR}/venv/bin/activate"

pip install --quiet flask

deactivate

ok "Flask installed in venv"

# ═══════════════════════════════════════════════════════════
# 4. CREATE SYSTEMD SERVICE
# ═══════════════════════════════════════════════════════════
log "Creating systemd service..."

cat > /etc/systemd/system/scrn-lab.service << 'UNIT'
[Unit]
Description=SCRN Vulnerable Lab Server
Documentation=https://github.com/higher-echelon/scrn-lab
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/scrn-lab
ExecStart=/opt/scrn-lab/venv/bin/python3 /opt/scrn-lab/app.py
Restart=on-failure
RestartSec=5
Environment=FLASK_ENV=development

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable scrn-lab.service
ok "Systemd service created (scrn-lab.service)"

# ═══════════════════════════════════════════════════════════
# 5. INITIALIZE DATABASE
# ═══════════════════════════════════════════════════════════
log "Initializing user database..."

cd "${APP_DIR}"
source "${APP_DIR}/venv/bin/activate"
python3 -c "
import sys
sys.path.insert(0, '.')
from app import init_db
init_db()
print('Database initialized.')
"
deactivate

ok "SQLite database created with default users"

# ═══════════════════════════════════════════════════════════
# 6. CREATE HELPER SCRIPTS
# ═══════════════════════════════════════════════════════════
log "Creating helper scripts..."

# Start script
cat > "${APP_DIR}/start.sh" << 'START'
#!/usr/bin/env bash
cd /opt/scrn-lab
source venv/bin/activate
echo ""
echo "  Starting SCRN Lab Server on http://0.0.0.0:8080"
echo "  Press Ctrl+C to stop"
echo ""
python3 app.py
START
chmod +x "${APP_DIR}/start.sh"

# Stop script
cat > "${APP_DIR}/stop.sh" << 'STOP'
#!/usr/bin/env bash
sudo systemctl stop scrn-lab.service
echo "SCRN Lab Server stopped."
STOP
chmod +x "${APP_DIR}/stop.sh"

# Reset database script
cat > "${APP_DIR}/reset-db.sh" << 'RESET'
#!/usr/bin/env bash
cd /opt/scrn-lab
rm -f users.db
source venv/bin/activate
python3 -c "from app import init_db; init_db(); print('Database reset.')"
deactivate
echo "Database reset to defaults."
RESET
chmod +x "${APP_DIR}/reset-db.sh"

ok "Helper scripts created"

# ═══════════════════════════════════════════════════════════
# 7. START THE SERVICE
# ═══════════════════════════════════════════════════════════
log "Starting SCRN Lab Server..."
systemctl start scrn-lab.service
sleep 2

if systemctl is-active --quiet scrn-lab.service; then
  ok "Service is running!"
else
  warn "Service may not have started — check: journalctl -u scrn-lab.service"
fi

# ═══════════════════════════════════════════════════════════
# DONE
# ═══════════════════════════════════════════════════════════

LOCAL_IP=$(hostname -I | awk '{print $1}')

echo ""
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  INSTALLATION COMPLETE${NC}"
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${CYAN}Application URL:${NC}  http://${LOCAL_IP}:8080"
echo -e "  ${CYAN}Install path:${NC}     ${APP_DIR}"
echo ""
echo -e "  ${AMBER}Default Credentials:${NC}"
echo -e "    admin    / admin123"
echo -e "    operator / operator"
echo -e "    engineer / hoover2024"
echo -e "    guest    / guest"
echo ""
echo -e "  ${CYAN}Service Commands:${NC}"
echo -e "    sudo systemctl start scrn-lab"
echo -e "    sudo systemctl stop scrn-lab"
echo -e "    sudo systemctl status scrn-lab"
echo -e "    journalctl -u scrn-lab -f"
echo ""
echo -e "  ${CYAN}Helper Scripts:${NC}"
echo -e "    ${APP_DIR}/start.sh     — Manual start"
echo -e "    ${APP_DIR}/stop.sh      — Stop service"
echo -e "    ${APP_DIR}/reset-db.sh  — Reset database"
echo ""
echo -e "  ${RED}${BOLD}⚠  THIS SERVER IS INTENTIONALLY VULNERABLE${NC}"
echo -e "  ${RED}   Do not expose to untrusted networks${NC}"
echo ""
